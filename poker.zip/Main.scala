import util.Random

//trait giving access to card suit value maps
trait NeedsCardTypes {

  var suits: Map[Int, String] = Map()

  suits += (1 -> "Clubs")
  suits += (2 -> "Spades")
  suits += (3 -> "Hearts")
  suits += (4 -> "Diamonds")

  var values: Map[Int, String] = Map()

  values += (1 -> "Ace")
  values += (2 -> "Two")
  values += (3 -> "Three")
  values += (4 -> "Four")
  values += (5 -> "Five")
  values += (6 -> "Six")
  values += (7 -> "Seven")
  values += (8 -> "Eight")
  values += (9 -> "Nine")
  values += (10 -> "Ten")
  values += (11 -> "Jack")
  values += (12 -> "Queen")
  values += (13 -> "King")

}

//card class, value = ace, 2, 3, ..., king
class Card(val _suit: Int, val _value: Int) extends NeedsCardTypes {

  //private class members
  private var suit: Int = _suit
  private var value: Int = _value

  private var played: Boolean = false

  //getters and setters per usual
  def getSuit() : Int = {

    return suit
  }

  def getValue() : Int = {

    return value
  }

  def setPlayed(_played: Boolean) {

    played = _played

  }

  def getPlayed() : Boolean = {

    return played

  }

  def print() {

    println(values(value) + " of " + suits(suit))

  }


}

//deck class
class Deck {

  //deck initialization code

  //array to hold all cards in deck
  private val cards = new Array[Card](52)
  
  //private vars for deck configuring
  private var suit = 0;
  private var value = 0;
  private var count = 0;

  //cycle through 13 card values for four suits
  for(suit <- 1 to 4){

    for(value <- 1 to 13){

      //add card with this suit and value to the deck
      cards(count) = new Card(suit, value)

      //increase location in the deck
      count = count + 1

    }

  }

  def reset() {

    for(x <- cards){

      x.setPlayed(false)

    }

  }

  def at(index : Int) : Card = {    

    return cards(index)

  }

  //return the length of the deck
  def length() : Int = {

    return cards.length

  }

  //print all the cards in the deck
  def print() {

    for(c <- cards){

      c.print

    }

  }

}

class PokerEvaluator(val _numCards: Int) {

  var rand = new scala.util.Random

  var handTallies: Map[String, Int] = Map()

  handTallies += ("Royal Flush" -> 0)
  handTallies += ("Straight Flush" -> 0)
  handTallies += ("Four of a kind" -> 0)
  handTallies += ("Full house" -> 0)
  handTallies += ("Flush" -> 0)
  handTallies += ("Straight" -> 0)
  handTallies += ("Three of a kind" -> 0)
  handTallies += ("Two pair" -> 0)
  handTallies += ("Pair" -> 0)
  handTallies += ("High Card" -> 0)

  //number of hands to play
  private var numHands: Int = 100000

  //number of cards in each hand
  private var numCards = _numCards

  //deck for use
  private val deck = new Deck

  //array to hold the hand of cards
  private var hand = new Array[Card](numCards)

  def setNumberOfHandsToPlay(_numHands: Int) {

    numHands = _numHands

  }

  def playAndDisplay() {

    //this will play all hands
    generateHands

    //display
    for((k,v) <- handTallies){

      println(k + ": " + v)

    }

  }

  def addCardToHand(_value: Int, _suit: String) {

    println("nothing to see here")

  }

  def generateHands() {

    //num cards actually in the hand
    var handSize = 0;

    //println("Here")

    for(dealt <- 1 to numHands){

      //while the hand length is less than
      //num cards supposed to be in hand
      while(handSize < numCards) {

        //pick a random index
        var index = Random.nextInt(deck.length);

        //has the card been played?
        if(deck.at(index).getPlayed == false) {

          hand(handSize) = deck.at(index)
          deck.at(index).setPlayed(true)

          handSize = handSize + 1

        }

      }

      //reset the hand!
      handSize = 0
      deck.reset

      //evaluate the hand
      evaluateHand


      //debugging, print hand
      // for(x <- hand) {

      //   x.print()

      // }

      //println


    }    

  }

  def evaluateHand() {

    //is it a royal flush?
    if(royalFlush){

      // println
      // println("ROYAL FLUSH")
      // println

      //update number of royalFlushes counted
      var cur: Int = handTallies("Royal Flush")
      cur = cur + 1
      handTallies += ("Royal Flush" -> cur)

    }
    else if(straightFlush){

      //println
      //println("STRAIGHT FLUSH")
      //println

      //update number counted
      var cur = handTallies("Straight Flush")
      cur = cur + 1
      handTallies += ("Straight Flush" -> cur)

    }
    else if(fourOfAKind){

      //println
      //println("FOUR OF A KIND")
      //println

      //update number
      var cur = handTallies("Four of a kind")
      cur = cur + 1
      handTallies += ("Four of a kind" -> cur)

    }
    else if(fullHouse){

      //println
      //println("FULLHOUSE")
      //println

      //update number counted
      var cur = handTallies("Full house")
      cur = cur + 1
      handTallies += ("Full house" -> cur)

    }
    else if(flush){

      //println
      //println("FLUSH")
      //println

      //update number counted
      var cur = handTallies("Flush")
      cur = cur + 1
      handTallies += ("Flush" -> cur)

    }
    else if(straight){

      //println
      //println("STRAIGHT")
      //println

      //update number counted
      var cur = handTallies("Straight")
      cur = cur + 1
      handTallies += ("Straight" -> cur)

      println

      //debugging, print hand
      for(x <- hand) {

        x.print()

      }

      println


    }
    else if(threeOfAKind){

      //println
      //println("THREE OF A KIND")
      //println

      //update number counted
      var cur = handTallies("Three of a kind")
      cur = cur + 1
      handTallies += ("Three of a kind" -> cur)

    }
    else if(twoPair){

      //println
      //println("TWO PAIR")
      //println

      //update number counted
      var cur = handTallies("Two pair")
      cur = cur + 1
      handTallies += ("Two pair" -> cur)

    }
    else if(pair){

      //println
      //println("PAIR")
      //println

      //update number counted
      var cur = handTallies("Pair")
      cur = cur + 1
      handTallies += ("Pair" -> cur)

    }
    else{

      //println
      //println("HIGH CARD")
      //println

      //update number counted
      var cur = handTallies("High Card")
      cur = cur + 1
      handTallies += ("High Card" -> cur)

    }

  }

  def royalFlush() : Boolean = {

    var retVal = true;

    var suit = hand(0).getSuit;

    //println("Suit: " + suit)

    //for each card in the current hand
    for(x <- hand){

      //if the card is less than ten, jack, queen, king...
      if(x.getValue < 10){

        //...and isn't an ace
        if(x.getValue != 1){

          //no royal flush here
          retVal = false
          
        }

      }

      //if the card doesn't match the first suit
      if(x.getSuit != suit){

        //no royal flush here
        retVal = false

      }


    }

    return retVal

  }

  def straightFlush() : Boolean = {

    var retVal = true;

    var suit = hand(0).getSuit;

    var highest = hand(0).getValue;
    var lowest = hand(0).getValue;

    //for each card in the current hand
    for(x <- hand){

      //keep track of highest and lowest values
      if(x.getValue > highest){

        highest = x.getValue

      }

      if(x.getValue < lowest){

        lowest = x.getValue

      }

      //if the card doesn't match the first suit
      if(x.getSuit != suit){

        //no flush here
        retVal = false

      }

    }

    //if the value spread is greater than 5...
    if((highest - lowest) > numCards){

      //no straight flush here
      retVal = false

    }

    //if there exists a pair in the hand (repeats)
    if(pair()){

      retVal = false

    }

    if(threeOfAKind()){

      retVal = false

    }


    return retVal

  }

  def fourOfAKind() : Boolean = {

    var retVal = false;

    var handVals: Map[Int, Int] = Map()

    handVals += (1 -> 0)
    handVals += (2 -> 0)
    handVals += (3 -> 0)
    handVals += (4 -> 0)
    handVals += (5 -> 0)
    handVals += (6 -> 0)
    handVals += (7 -> 0)
    handVals += (8 -> 0)
    handVals += (9 -> 0)
    handVals += (10 -> 0)
    handVals += (11 -> 0)
    handVals += (12 -> 0)
    handVals += (13 -> 0)

    //for each card in the current hand
    for(x <- hand){

      //get current num of this value in hand
      var num = handVals(x.getValue());

      //add one
      num = num + 1;

      //update map
      handVals += (x.getValue() -> num)

    }

    for((k,v) <- handVals) {

      if(v >= 4){

        retVal = true

      }

    }

    return retVal



  }

  def fullHouse() : Boolean = {

    var retVal = false;

    var handVals: Map[Int, Int] = Map()

    handVals += (1 -> 0)
    handVals += (2 -> 0)
    handVals += (3 -> 0)
    handVals += (4 -> 0)
    handVals += (5 -> 0)
    handVals += (6 -> 0)
    handVals += (7 -> 0)
    handVals += (8 -> 0)
    handVals += (9 -> 0)
    handVals += (10 -> 0)
    handVals += (11 -> 0)
    handVals += (12 -> 0)
    handVals += (13 -> 0)

    //for each card in the current hand
    for(x <- hand){

      //get current num of this value in hand
      var num = handVals(x.getValue());

      //add one
      num = num + 1;

      //update map
      handVals += (x.getValue() -> num)

    }

    var numPair = 0;
    var thrice = 0;

    for((k,v) <- handVals) {

      if(v == 2){

        numPair = numPair + 1

      }
      if(v == 3){

        thrice = thrice + 1

      }

    }

    if(thrice == 1 && numPair >= 1){

      retVal = true

    }

    return retVal



  }

  def flush() : Boolean = {

    var retVal = true;

    var suit = hand(0).getSuit;

    //println("Suit: " + suit)

    //going to have to modify for seven card...

    //for each card in the current hand
    for(x <- hand){

      //if the card doesn't match the first suit
      if(x.getSuit != suit){

        //no royal flush here
        retVal = false

      }


    }

    return retVal

  }

  def straight() : Boolean = {

    var retVal = true;

    var highest = hand(0).getValue;
    var lowest = hand(0).getValue;

    //for each card in the current hand
    for(x <- hand){

      //keep track of highest and lowest values
      if(x.getValue > highest){

        highest = x.getValue

      }

      if(x.getValue < lowest){

        lowest = x.getValue

      }

    }

    //if the value spread is greater than 5...
    if((highest - lowest) > numCards){

      //no straight here
      retVal = false

    }

    //if there exists a pair in the hand (repeats)
    if(pair()){

      retVal = false

    }

    if(threeOfAKind()){

      retVal = false

    }


    return retVal

  }

  def threeOfAKind() : Boolean = {

    var retVal = false;

    var handVals: Map[Int, Int] = Map()

    handVals += (1 -> 0)
    handVals += (2 -> 0)
    handVals += (3 -> 0)
    handVals += (4 -> 0)
    handVals += (5 -> 0)
    handVals += (6 -> 0)
    handVals += (7 -> 0)
    handVals += (8 -> 0)
    handVals += (9 -> 0)
    handVals += (10 -> 0)
    handVals += (11 -> 0)
    handVals += (12 -> 0)
    handVals += (13 -> 0)

    //for each card in the current hand
    for(x <- hand){

      //get current num of this value in hand
      var num = handVals(x.getValue());

      //add one
      num = num + 1;

      //update map
      handVals += (x.getValue() -> num)

    }

    for((k,v) <- handVals) {

      if(v == 3){

          retVal = true

      }

    }

    return retVal



  }

  def twoPair() : Boolean = {

    var retVal = false;

    var handVals: Map[Int, Int] = Map()

    handVals += (1 -> 0)
    handVals += (2 -> 0)
    handVals += (3 -> 0)
    handVals += (4 -> 0)
    handVals += (5 -> 0)
    handVals += (6 -> 0)
    handVals += (7 -> 0)
    handVals += (8 -> 0)
    handVals += (9 -> 0)
    handVals += (10 -> 0)
    handVals += (11 -> 0)
    handVals += (12 -> 0)
    handVals += (13 -> 0)

    //for each card in the current hand
    for(x <- hand){

      //get current num of this value in hand
      var num = handVals(x.getValue());

      //add one
      num = num + 1;

      //update map
      handVals += (x.getValue() -> num)

    }

    var numPair = 0;

    for((k,v) <- handVals) {

      if(v == 2){

        numPair = numPair + 1

        if(numPair == 2) {
          retVal = true

        }

      }

    }

    return retVal



  }

  def pair() : Boolean = {

    var retVal = false;

    var handVals: Map[Int, Int] = Map()

    handVals += (1 -> 0)
    handVals += (2 -> 0)
    handVals += (3 -> 0)
    handVals += (4 -> 0)
    handVals += (5 -> 0)
    handVals += (6 -> 0)
    handVals += (7 -> 0)
    handVals += (8 -> 0)
    handVals += (9 -> 0)
    handVals += (10 -> 0)
    handVals += (11 -> 0)
    handVals += (12 -> 0)
    handVals += (13 -> 0)

    //for each card in the current hand
    for(x <- hand){

      //get current num of this value in hand
      var num = handVals(x.getValue());

      //add one
      num = num + 1;

      //update map
      handVals += (x.getValue() -> num)

    }

    for((k,v) <- handVals) {

      if(v == 2){

        retVal = true

      }

    }

    return retVal



  }

}

//this is the main module where
//main function is kept
object Main {

  def main(args: Array[String]) {

    val e1 = new PokerEvaluator(7);

    e1.playAndDisplay


    }
}
